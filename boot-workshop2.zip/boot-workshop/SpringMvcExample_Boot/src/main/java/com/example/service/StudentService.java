package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.StudentDAO;

@Service
public class StudentService {
	@Autowired
private StudentDAO studentDAO;
	public int deleteStudent(Integer sid) {
		return studentDAO.deleteStudent(sid);
		
	}

}
