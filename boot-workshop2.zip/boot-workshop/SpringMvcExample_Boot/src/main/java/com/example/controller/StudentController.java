package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.service.StudentService;

@Controller
public class StudentController {
	@Autowired
	private StudentService studentService;
	
@RequestMapping(value="deleteStudent",
method=RequestMethod.GET)	
public ModelAndView showDeleteStudentPage(){
String viewName="deleteStudent";
return new ModelAndView(viewName);
}
@RequestMapping(value="deleteStudent",
method=RequestMethod.POST)	
public ModelAndView deleteStudent(
	@RequestParam("sid") Integer sid){
	String status="Student Delete Failure";
	int count=studentService.deleteStudent(sid);
if(count>0){
	status="Student Delete Success";
}
String viewName="deleteStudent";
return new ModelAndView(viewName,"status",status);

}
}
