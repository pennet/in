package com.nareshit.service;

import org.springframework.stereotype.Service;

@Service("helloService") //stereo type annotation
public class HelloService {
public String sayHello(String name){
	String msg="Hello "+name+" welcome to spring boot";
	return msg;
}
}
