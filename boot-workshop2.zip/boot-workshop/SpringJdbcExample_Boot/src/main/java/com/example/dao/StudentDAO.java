package com.example.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("studentDAO")
public class StudentDAO {
	@Autowired
private JdbcTemplate jdbcTemplate;
public int updateStudentDetails
(int sid,String course,double fee){
String sql="update student1 set course=?,fee=? where sid=?";

  int count=jdbcTemplate.update(sql,course,fee,sid);
  return count;
}
}


