package com.nt.service;

import com.nt.dto.ProfileDTO;

public interface ProfileService {
	public ProfileDTO  showProfile(int pid);
}
