package com.nt.dao;

import com.nt.bo.ProfileBO;

public interface ProfileDAO {
	
	public ProfileBO getProfile(int pid);

}
