package com.nt.utils;

import java.io.Serializable;

public class CommonsUtil implements Cloneable,Serializable{
	private static final long serialVersionUID=2L;
	
@Override
	public Object clone() throws CloneNotSupportedException {
	
		return super.clone();
	}

}
