package com.nt.comps;

public interface Courier {
	public void deliver(int orderId);

}
