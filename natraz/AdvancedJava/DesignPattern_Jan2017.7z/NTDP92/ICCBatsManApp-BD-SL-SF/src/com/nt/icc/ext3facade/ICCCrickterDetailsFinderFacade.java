package com.nt.icc.ext3facade;

import com.nt.dto.BatsmanInputsDTO;
import com.nt.dto.BatsmanProfileDTO;

public interface ICCCrickterDetailsFinderFacade {
	
	public BatsmanProfileDTO  getCrickterDetails(BatsmanInputsDTO ipDTO);
	

}
