package com.nt.icc.ext1;

import com.nt.dto.BatsmanIdDetailsDTO;
import com.nt.dto.BatsmanInputsDTO;

public interface ICCCrickerIdFinderComp {
	
	public BatsmanIdDetailsDTO  findBatsmanId(BatsmanInputsDTO dto);

}
