package com.nt.icc.ext2;

import com.nt.dto.BatsmanIdDetailsDTO;
import com.nt.dto.BatsmanProfileDTO;

public interface ICCCrickterProfileFinderComp {
	
	public BatsmanProfileDTO  findBatsmanProfile(BatsmanIdDetailsDTO iDdto);

}
