package com.nt.afp;

public class ExcelStudentDAO implements DAO {

	@Override
	public void insert() {
	  System.out.println("ExcelStudentDAO:insertering Student Info to Excel sheet");
	}

}
