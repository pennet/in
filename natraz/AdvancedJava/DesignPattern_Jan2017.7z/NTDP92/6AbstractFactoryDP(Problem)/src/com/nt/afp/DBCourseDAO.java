package com.nt.afp;

public class DBCourseDAO implements DAO {

	@Override
	public void insert() {
	  System.out.println("DBCourseDAO:insertering Course Info to DB s/w");
	}

}
