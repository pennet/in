package com.nt.afp;

public class ExcelCourseDAO implements DAO {

	@Override
	public void insert() {
	  System.out.println("ExcelCourseDAO:insertering Course Info to Excel sheet");
	}

}
