package com.nt.afp;

public class DBStudentDAO implements DAO {

	@Override
	public void insert() {
	  System.out.println("DBStudentDAO:insertering Student Info to DB s/w");
	}

}
