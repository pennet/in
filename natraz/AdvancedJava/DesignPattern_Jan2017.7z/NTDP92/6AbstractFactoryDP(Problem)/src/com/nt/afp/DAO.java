package com.nt.afp;

public interface DAO {
  public void insert();
}
