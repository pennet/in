package com.nt.errors;

public class EmployeeRegistrationException  extends Exception{
	public EmployeeRegistrationException() {
            super();
	}
	public EmployeeRegistrationException(String msg) {
         super(msg);
	}
	
	

}
