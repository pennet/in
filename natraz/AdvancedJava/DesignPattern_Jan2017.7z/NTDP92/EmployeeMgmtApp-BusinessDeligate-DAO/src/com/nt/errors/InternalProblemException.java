package com.nt.errors;

public class InternalProblemException  extends Exception{
	public InternalProblemException() {
            super();
	}
	public InternalProblemException(String msg) {
         super(msg);
	}
	
	

}
