package com.nt.bo;

public class FinanceEmployeeBO extends HREmployeeBO {
	private float empSalary;

	public float getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(float empSalary) {
		this.empSalary = empSalary;
	}

}
