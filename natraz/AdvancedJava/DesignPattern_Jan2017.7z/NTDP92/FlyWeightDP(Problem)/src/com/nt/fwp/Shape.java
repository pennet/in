package com.nt.fwp;

public interface Shape {
	public void draw();
}
