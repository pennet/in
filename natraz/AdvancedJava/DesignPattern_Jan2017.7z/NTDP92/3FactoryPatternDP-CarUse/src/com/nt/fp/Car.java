package com.nt.fp;

public interface Car {
	public void manifature();
	public  void roadTest();
	public  void deliver();

}
