package com.nt.afp;

public interface DAOFactory {
	public DAO getInstance(String type);

}
