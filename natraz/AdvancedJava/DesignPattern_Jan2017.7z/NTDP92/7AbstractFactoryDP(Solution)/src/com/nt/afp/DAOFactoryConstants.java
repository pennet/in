package com.nt.afp;

public interface DAOFactoryConstants {
	String STORE_DB="DATABASE";
	String STORE_EXCEL="Excel";
	String TYPE_STUDENT="student";
	String TYPE_COURSE="course";
}
