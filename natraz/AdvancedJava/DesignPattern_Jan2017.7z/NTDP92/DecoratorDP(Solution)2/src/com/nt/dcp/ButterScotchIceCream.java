package com.nt.dcp;

public class ButterScotchIceCream implements IceCream {

	@Override
	public void prepare() {
		System.out.println("Preparing ButterScotch IceCream");
		
	}

}
