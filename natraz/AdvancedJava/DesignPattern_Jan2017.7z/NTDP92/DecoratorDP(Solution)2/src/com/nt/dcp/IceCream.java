package com.nt.dcp;

public interface IceCream {
	 public void prepare();
}
