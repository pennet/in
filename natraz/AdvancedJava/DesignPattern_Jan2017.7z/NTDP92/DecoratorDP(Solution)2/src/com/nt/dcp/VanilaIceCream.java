package com.nt.dcp;

public class VanilaIceCream implements IceCream {

	@Override
	public void prepare() {
		System.out.println("Preparing Vanila IceCream");
		
	}

}
