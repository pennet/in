package com.nt.fmp;

public class DiscoverBike extends Bike {
  private  String milege;
	@Override
	public void drive() {
		System.out.println("Driving Discover Bike");
	}//drive()
}//class
