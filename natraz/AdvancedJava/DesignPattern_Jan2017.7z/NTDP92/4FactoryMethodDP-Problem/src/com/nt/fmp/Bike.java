package com.nt.fmp;

public  abstract class Bike {
	public String bodyColor;
	public int engineCC; 
	
	public  abstract void drive();

}
