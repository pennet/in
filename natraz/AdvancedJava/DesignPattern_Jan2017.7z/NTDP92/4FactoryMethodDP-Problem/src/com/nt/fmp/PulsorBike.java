package com.nt.fmp;

public class PulsorBike extends Bike {
  private  String pickupPower;
	@Override
	public void drive() {
		System.out.println("Driving PulsorBike");
	}//drive()
}//class
