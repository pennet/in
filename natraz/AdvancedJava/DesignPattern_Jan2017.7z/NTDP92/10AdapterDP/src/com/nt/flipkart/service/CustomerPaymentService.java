package com.nt.flipkart.service;

public interface CustomerPaymentService {
  public String payShoppingAmount(int cardNo,String bankName,float amount);
}
