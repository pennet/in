package com.nt.dcp;

public class DryFruitButterScotchCream extends ButterScotchIceCream {
	  public void prepare(){
	      super.prepare();
	      addDryFruits();
	      }
	   private void addDryFruits(){
	         System.out.println("adding dryfruits");
	       }
}//class
