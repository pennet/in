package com.nt.pdp;

public interface BankService {
	
	public String transferMoney(int srcAcno,int destAcno,float amount);

}
