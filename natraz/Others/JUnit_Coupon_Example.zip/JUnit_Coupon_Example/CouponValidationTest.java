//CouponValidationTest.java
package  pack1;
import java.util.*;
import org.junit.*;
public class CouponValidationTest {
	ValidateCoupons valCoupons;
	@Before
	public void setUp() throws Exception {
		 valCoupons = new ValidateCoupons();
	}
	@After
	public void tearDown() throws Exception {
		valCoupons=null;
	}
	@Test
	public void testValidityOfCoupons() {
		//Create expired coupon (Today > Coupon_enddate) (Invalid Coupon)
		Coupon cp1 = new Coupon();
		Calendar startCal = Calendar.getInstance();
		Calendar endCal = Calendar.getInstance();

		startCal.set(2017,4, 13); //13th may
		endCal.set(2017,5,28);   //28th  june
		cp1.setStartDate(startCal.getTime());
		cp1.setEndDate(endCal.getTime());

		//Create future coupon (Today < Coupon_StartDate) (Invalid Coupon)
		Coupon cp2 = new Coupon();
		startCal.set(2017,11,1);  //1st  dec
		endCal.set(2017,11,31); //31st  dec
		cp2.setStartDate(startCal.getTime());
		cp2.setEndDate(endCal.getTime());

		//Create a coupon with start date as null & Today > Coupon_enddate (Invalid Coupon)
		Coupon cp3 = new Coupon();
		endCal.set(2017,6,23); //23rd  July
		cp3.setStartDate(null);
		cp3.setEndDate(endCal.getTime());

		//Create a coupon with end date as null & Today > Coupon_StartDate (Valid Coupon)
		Coupon cp4 = new Coupon();
		startCal.set(2017,6,1); //1st july
		cp4.setStartDate(startCal.getTime());
		cp4.setEndDate(null);

		//Create a coupon with startdate < today < end date (Valid Coupon)
		Coupon cp5 = new Coupon();
		startCal.set(2017,0,1); //1st Jan
		endCal.set(2017,11,31);//31st  dec
		cp5.setStartDate(startCal.getTime());
		cp5.setEndDate(endCal.getTime());

		List<Coupon> cpList = new ArrayList<Coupon>();
		cpList.add(cp1);
		cpList.add(cp2);
		cpList.add(cp3);
		cpList.add(cp4);
		cpList.add(cp5);

		List<Coupon> validCouponList = valCoupons.validityOfCoupons(cpList);

		Assert.assertEquals(3, validCouponList.size());
	}
}
