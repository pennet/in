//ValidateCoupons.java
package  pack1;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class ValidateCoupons
{
    public  List<Coupon>  validityOfCoupons(List<Coupon> coupons)
		{
        Date now = new Date(System.currentTimeMillis());
        List<Coupon>   couponsToRemove = new ArrayList<Coupon>();
		//for each loop
        for (Coupon coupon : coupons) {
			//If the coupon is valid for future date with startdate as not null then add to coupons to remove list.
            if ((coupon.getStartDate() != null) && (coupon.getStartDate().after(now))){
                couponsToRemove.add(coupon);
            } 
			//if coupon is already expired then remove that coupon
			else if (coupon.getEndDate() != null && coupon.getEndDate().before(now)){
                couponsToRemove.add(coupon);
            }
        }
		// remove all the non valid coupons from the original list
        for (Coupon coupon : couponsToRemove) {
            coupons.remove(coupon);
        }
		//return only valid coupons
        return coupons;
    }
}
