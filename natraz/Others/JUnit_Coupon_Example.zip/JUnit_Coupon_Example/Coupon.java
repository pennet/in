//Coupon.java
package  pack1;
import  java.util.Date;
public  class  Coupon
{
	private  Date  startDate;
	private  Date  endDate;
	// setters  & getters

	public void setStartDate(Date  startDate)
	{
		this.startDate=startDate;
	}
	public  Date  getStartDate()
	{
		return  startDate;
	}
	public  void  setEndDate(Date  endDate)
	{
		this.endDate=endDate;
	}
	public  Date  getEndDate()
	{
		return  endDate;
	}

};