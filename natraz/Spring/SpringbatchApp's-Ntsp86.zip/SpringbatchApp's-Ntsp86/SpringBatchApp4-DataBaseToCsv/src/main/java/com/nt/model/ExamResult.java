package com.nt.model;

import org.joda.time.LocalDate;

public class ExamResult {
	private int id;
	private int sem;
	private LocalDate  dob;
	private double percentage;
	


	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSem() {
		return sem;
	}

	public void setSem(int sem) {
		this.sem = sem;
	}

	public LocalDate  getDob() {
		return dob;
	}
	
	public void setDob(LocalDate  dob) {
		this.dob = dob;
	}
	
	public double getPercentage() {
		return percentage;
	}
	
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	@Override
	public String toString() {
		return "ExamResult [id=" + id + ", sem=" + sem + ", dob=" + dob + ", percentage=" + percentage + "]";
	}

	
	
	
}
