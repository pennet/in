package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(value="/srv1", name="sone")
public class MailServlet extends HttpServlet
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//read input  values from request
		String  to = request.getParameter("to");
		String  subject=request.getParameter("subject");
		String  msg=request.getParameter("message");
		
		//step-1
		//configure  smtp server  properties
		Properties     props=new     Properties();
		
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.auth", "true");
		
		try
		{
			//step-2
			// Get the Session object.
		      Session session = Session.getInstance( props ,
		      new javax.mail.Authenticator() {
		         protected  PasswordAuthentication   getPasswordAuthentication() {
		            return new PasswordAuthentication("mad11109911@gmail.com","mad_11109911");
		         }
		      });
		      //step-3
		      // Create a  MimeMessage object.
		      Message message = new MimeMessage(session);
		      // Set To  address
		      message.setRecipient(Message.RecipientType.TO,
		         new InternetAddress(to));
	          // Set Subject
		      message.setSubject(subject);
              //  set the  message
	          message.setText(msg);
	          
	          //step-4
	         // Send message
	         Transport  t = session.getTransport("smtp");
	         t.send(message);
	         

	         response.setContentType("text/html");
	         PrintWriter  out=response.getWriter();
	         out.println("<h1> E-mail delivered successfully to : "+ to +"</h1>");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
