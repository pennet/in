package com.axis2clientexample.service;

import com.axis2clientexample.vo.ProductVO;

public interface ProductServiceClient {
public boolean registerProduct(ProductVO productVO);
}
