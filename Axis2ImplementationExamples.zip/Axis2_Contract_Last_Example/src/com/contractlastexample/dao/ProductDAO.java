package com.contractlastexample.dao;

import com.contractlastexample.bo.ProductBO;

public interface ProductDAO {
public int registerProduct(ProductBO productBo);
}
