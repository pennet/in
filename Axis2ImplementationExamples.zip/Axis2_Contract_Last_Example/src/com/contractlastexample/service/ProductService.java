package com.contractlastexample.service;

import com.contractlastexample.bo.ProductBO;

public interface ProductService {
public boolean registerProduct(ProductBO productBO);
}
