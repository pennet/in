package com.jerseyexample.dao;

import com.jerseyexample.domain.Book;

public interface BookDAO {
public int registerBook(Book book);
}
