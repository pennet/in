package com.nareshit;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nareshit.service.EmployeeService;
import com.nareshit.service.EmployeeServiceImpl;
public class EmployeeTestCases {
	
	private static EmployeeService empService;
	@BeforeClass
	public static void myinit(){
	empService=new EmployeeServiceImpl();
	}
	/**if employee jobType is permanent
	 * if employee salary is <=10,000 da is 10%
	 * if employee salary is <=150000 da is 12.5%
	 * if employee salary is >15000 da is 15 %
	 
	 if employee jobType is contract
	 * if employee salary is <=10,000 da is 7.5%
	 * if employee salary is <=150000 da is 10.0%
	 * if employee salary is >15000 da is 12.5 %
	 */
	@Test
public void calculateDaTestCase(){
	Assert.assertEquals(1000,empService.calculateEmployeeDa("permanent",10000),0.0);
	Assert.assertEquals(1875,empService.calculateEmployeeDa("permanent",15000),0.0);
	Assert.assertEquals(2400,empService.calculateEmployeeDa("permanent",16000),0.0);
	
	Assert.assertEquals(750,empService.calculateEmployeeDa("contract",10000),0.0);
	Assert.assertEquals(1500,empService.calculateEmployeeDa("contract",15000),0.0);
	Assert.assertEquals(2000,empService.calculateEmployeeDa("contract",16000),0.0);

	}
	/**if employee jobType is permanent
	 * if employee salary is <=10,000 hra is 20%
	 * if employee salary is <=150000 hra is 22.5%
	 * if employee salary is >15000 hra is 25 %
	 
	 if employee jobType is contract
	 * if employee salary is <=10,000 hra is 12.5%
	 * if employee salary is <=150000 hra is 15.0%
	 * if employee salary is >15000 hra is 20 %
	 */
	@Test
	public void calculateHraTestCase(){
		Assert.assertEquals(2000,empService.calculateEmployeeHra("permanent",10000),0.0);
		Assert.assertEquals(3375,empService.calculateEmployeeHra("permanent",15000),0.0);
		Assert.assertEquals(4000,empService.calculateEmployeeHra("permanent",16000),0.0);
		
		Assert.assertEquals(1250,empService.calculateEmployeeHra("contract",10000),0.0);
		Assert.assertEquals(2250,empService.calculateEmployeeHra("contract",15000),0.0);
		Assert.assertEquals(3200,empService.calculateEmployeeHra("contract",16000),0.0);
		
	}
}
