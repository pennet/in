package com.nareshit.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;

import com.mysql.jdbc.Driver;
import com.nareshit.domain.Employee;

@Repository
public class EmployeeDAOImpl 
implements EmployeeDAO{
	@Autowired
private DataSource dataSource;
private static Logger logger=Logger.getLogger(EmployeeDAOImpl.class);
public int registerEmployee(Employee emp){
int count=0;
	try{
Connection con=dataSource.getConnection();
String sql="insert into employee values(?,?,?,?,?,?,?)";
PreparedStatement pst=con.prepareStatement(sql);
pst.setInt(1,emp.getEmpNo());
pst.setString(2,emp.getEmpName());
pst.setString(3,emp.getJobType());
pst.setDouble(4,emp.getBasicSalary());
pst.setDouble(5,emp.getDa());
pst.setDouble(6,emp.getHra());
pst.setDouble(7,emp.getTotalSalary());
 count=pst.executeUpdate();
}catch(SQLException se){
logger.error("Exception Occured while registering the Employee :"+se.getMessage());
}
return count;
}

	public int updateEmployeeSalary(Employee emp) {
     int count=0;
  try{
  Connection con=dataSource.getConnection();
  String sql="update employee set basicSalary=?,da=?,hra=?,totalSalary=? where empNo=?";
  PreparedStatement pst=con.prepareStatement(sql);
  pst.setDouble(1,emp.getBasicSalary());
  pst.setDouble(2,emp.getDa());
  pst.setDouble(3,emp.getHra());
  pst.setDouble(4,emp.getTotalSalary());
  pst.setInt(5,emp.getEmpNo());
  count=pst.executeUpdate();
  }catch(SQLException se){
	  logger.error("Exception Occured while updating the Employee Salary :"+se.getMessage());

  }
		return count;
	}

	public int deleteEmployee(int empNo) {
	int count=0;	
	try{
	Connection con=dataSource.getConnection();
	String sql="delete from employee where empNo=?";
PreparedStatement pst=con.prepareStatement(sql);
pst.setInt(1,empNo);
count=pst.executeUpdate();
	}catch(SQLException se){
		logger.error("Exception Occured while deleting the Employee :"+se.getMessage());

	}
		return count;
	}

public Employee searchEmployee(int empNo) {
Employee emp=null;
try{
Connection con=dataSource.getConnection();
String sql="select name,jobType,basicSalary,da,hra,totalSalary from employee where empNo=?";
PreparedStatement pst=con.prepareStatement(sql);
pst.setInt(1,empNo);
ResultSet rs=pst.executeQuery();
if(rs.next()){
	emp=new Employee();
	emp.setEmpNo(empNo);
	emp.setEmpName(rs.getString(1));
	emp.setJobType(rs.getString(2));
	emp.setBasicSalary(rs.getDouble(3));
	emp.setDa(rs.getDouble(4));
	emp.setHra(rs.getDouble(5));
	emp.setTotalSalary(rs.getDouble(6));
	}
}catch(SQLException se){
	logger.error("Exception Occured while searching the Employee :"+se.getMessage());

}
	return emp;
	}
}
