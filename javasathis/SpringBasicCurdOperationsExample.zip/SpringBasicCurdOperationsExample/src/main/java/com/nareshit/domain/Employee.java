package com.nareshit.domain;

public class Employee {
private int empNo;
private String empName,jobType;
private double da,hra,basicSalary,totalSalary;
public int getEmpNo() {
	return empNo;
}
public void setEmpNo(int empNo) {
	this.empNo = empNo;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getJobType() {
	return jobType;
}
public void setJobType(String jobType) {
	this.jobType = jobType;
}
public double getDa() {
	return da;
}
public void setDa(double da) {
	this.da = da;
}
public double getHra() {
	return hra;
}
public void setHra(double hra) {
	this.hra = hra;
}
public double getBasicSalary() {
	return basicSalary;
}
public void setBasicSalary(double basicSalary) {
	this.basicSalary = basicSalary;
}
public double getTotalSalary() {
	return totalSalary;
}
public void setTotalSalary(double totalSalary) {
	this.totalSalary = totalSalary;
}

}
