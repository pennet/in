package com.nareshit.client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nareshit.cfg.MyBeans;
import com.nareshit.domain.Employee;
import com.nareshit.service.EmployeeService;
public class App {
   public static void main( String[] args){
ApplicationContext context=new
AnnotationConfigApplicationContext(MyBeans.class);
EmployeeService empService=context.getBean("empService",EmployeeService.class);

/*Employee emp=new Employee();
emp.setEmpNo(102);
emp.setEmpName("raja");
emp.setJobType("contract");
emp.setBasicSalary(8000.0);
System.out.println(empService.registerEmployee(emp));
*/
/*Employee emp=new Employee();
emp.setEmpNo(102);
emp.setJobType("contract");
emp.setBasicSalary(9500.0);
System.out.println(empService.updateEmployeeSalary(emp));
*/
/*Employee emp=empService.searchEmployee(102);
System.out.println(emp.getEmpName()+" "+emp.getBasicSalary()+" "+emp.getDa()+" "+emp.getHra()+" "+emp.getTotalSalary()+" "+emp.getJobType());
*/
System.out.println(empService.deleteEmployee(102));

   }
}
