package com.nareshit.service;

import com.nareshit.domain.Employee;

public interface EmployeeService {
public String registerEmployee(Employee emp);
public String updateEmployeeSalary(Employee emp);
public String deleteEmployee(int empNo);
public Employee searchEmployee(int empNo);
public double calculateEmployeeDa(String jobType,double basicSalary);
public double calculateEmployeeHra(String jobType,double basicSalary);
}
