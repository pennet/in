package com.nareshit.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sun.launcher.resources.launcher;

import com.nareshit.dao.EmployeeDAO;
import com.nareshit.domain.Employee;
@Service("empService")
public class EmployeeServiceImpl
implements EmployeeService{
private static Logger logger=Logger.getLogger(EmployeeServiceImpl.class);	
	@Autowired
private EmployeeDAO employeeDAO;
public String registerEmployee(Employee emp) {
logger.info("Entered into registerEmployee() ");

String status="Registration is Failure";
  emp.setDa(calculateEmployeeDa(emp.getJobType(),emp.getBasicSalary()));
  emp.setHra(calculateEmployeeHra(emp.getJobType(),emp.getBasicSalary()));
  emp.setTotalSalary(emp.getDa()+emp.getHra()+emp.getBasicSalary());
  int count=employeeDAO.registerEmployee(emp);
  if(count>0){
	  status="registration is succes";
  }
  logger.info("Execution completed on registerEmployee() : "+status);

  return status;
	}

public String updateEmployeeSalary(Employee emp) {
	logger.info("Entered into updateEmployeeSalary() ");
		
	String status="Update Failure";
//input's in employee obj -->empNo,jobType,newBasicSalary
	emp.setDa(calculateEmployeeDa(emp.getJobType(),emp.getBasicSalary()));
	emp.setHra(calculateEmployeeHra(emp.getJobType(),emp.getBasicSalary()));
	emp.setTotalSalary(emp.getDa()+emp.getHra()+emp.getBasicSalary());
	int count=employeeDAO.updateEmployeeSalary(emp);
		if(count>0){
		status="Update Success";	
		}
		 logger.info("Execution completed on updateEmployeeSalary() : "+status);
		
		return status;
	}

	public String deleteEmployee(int empNo) {
		logger.info("Entered into updateEmployeeSalary() ");
		
		String status="Delete Failure";
		int count=employeeDAO.deleteEmployee(empNo);
		if(count>0){
		status="Delete Success";	
		}
		 logger.info("Execution completed on deleteEmployee() : "+status);
				
		return status;
	}

	public Employee searchEmployee(int empNo) {
		logger.info("Entered into searchEmployee () : "+empNo);
		
		//condition
		Employee emp=employeeDAO.searchEmployee(empNo);
		return emp;
	}
/**if employee jobType is permanent
 * if employee salary is <=10,000 da is 10%
 * if employee salary is <=150000 da is 12.5%
 * if employee salary is >15000 da is 15 %
 
 if employee jobType is contract
 * if employee salary is <=10,000 da is 7.5%
 * if employee salary is <=150000 da is 10.0%
 * if employee salary is >15000 da is 12.5 %
 */
public double calculateEmployeeDa(String jobType,double basicSalary) {
 double da=0.0;
	if(jobType.equalsIgnoreCase("permanent")){
		if(basicSalary<=10000){
			da=basicSalary*0.1;
			
			/*(OR) da=basicSalary*10/100;*/
		}else if(basicSalary<=15000){
			da=basicSalary*0.125;
		}
		else{
			da=basicSalary*0.15;
		}
	}else{
		if(basicSalary<=10000){
			da=basicSalary*0.075;
			
			/*(OR) da=basicSalary*10/100;*/
		}else if(basicSalary<=15000){
			da=basicSalary*0.1;
		}
		else{
			da=basicSalary*0.125;
		}
	}
		return da;
	}
/**if employee jobType is permanent
 * if employee salary is <=10,000 hra is 20%
 * if employee salary is <=150000 hra is 22.5%
 * if employee salary is >15000 hra is 25 %
 
 if employee jobType is contract
 * if employee salary is <=10,000 hra is 12.5%
 * if employee salary is <=150000 hra is 15.0%
 * if employee salary is >15000 hra is 20 %
 */
	public double calculateEmployeeHra(String jobType,double basicSalary) {
		double hra=0.0;
		if(jobType.equalsIgnoreCase("permanent")){
			if(basicSalary<=10000){
				hra=basicSalary*0.2;
				
				
			}else if(basicSalary<=15000){
				hra=basicSalary*0.225;
			}
			else{
				hra=basicSalary*0.25;
			}
		}else{
			if(basicSalary<=10000){
				hra=basicSalary*0.125;
				
			
			}else if(basicSalary<=15000){
				hra=basicSalary*0.15;
			}
			else{
				hra=basicSalary*0.20;
			}
		}
		return hra;
	}
}
