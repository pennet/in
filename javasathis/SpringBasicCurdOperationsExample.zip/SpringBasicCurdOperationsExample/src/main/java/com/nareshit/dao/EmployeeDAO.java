package com.nareshit.dao;

import com.nareshit.domain.Employee;

public interface EmployeeDAO {
public int registerEmployee(Employee emp);

public int updateEmployeeSalary(Employee emp);

public int deleteEmployee(int empNo);

public Employee searchEmployee(int empNo);
}
