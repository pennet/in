package com.nareshit.cfg;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages={"com.nareshit.service,com.nareshit.dao"})
public class MyBeans {
	@Value("${db.driverClassName}")
private String driverClassName;
	@Value("${db.url}")
private String url;
	@Value("${db.username}")
private String username;
	@Value("${db.password}")
private String password;
@Bean
public static PropertyPlaceholderConfigurer 
placeholderConfigurer(){
PropertyPlaceholderConfigurer 
placeholderConfigurer=new PropertyPlaceholderConfigurer();
placeholderConfigurer.setLocation(new ClassPathResource("com/nareshit/cfg/database.properties"));
return placeholderConfigurer;
}
@Bean
public DataSource dataSource(){
	DriverManagerDataSource dataSource=new
	DriverManagerDataSource();
dataSource.setDriverClassName(driverClassName);
dataSource.setUrl(url);
dataSource.setUsername(username);
dataSource.setPassword(password);
return dataSource;
}

}
