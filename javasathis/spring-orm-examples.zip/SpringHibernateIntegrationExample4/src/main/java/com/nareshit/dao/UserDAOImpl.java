package com.nareshit.dao;

import java.util.List;

import javax.jws.soap.SOAPBinding.Use;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nareshit.pojo.User;

@Repository("userDao")
public class UserDAOImpl implements
UserDAO{
     @Autowired
	private SessionFactory sessionFactory;

	public List<User> getAllUsers() {
	Session session=sessionFactory.openSession();
	Criteria criteria=session.createCriteria(User.class);
	  List<User> list=criteria.list();
	session.close();
		return list;
	}

}
