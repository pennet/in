package com.nareshit.dao;

import java.util.List;

import com.nareshit.pojo.User;

public interface UserDAO {
public List<User> getAllUsers();
}
