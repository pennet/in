package com.nareshit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.nareshit.pojo.User;
@Repository("userDao")
public class UserDAOImpl
implements UserDAO{
	@Autowired
 private HibernateTemplate hibernateTemplate;
	public List<User> getAllUsers() {
List<User> list=hibernateTemplate.execute
(new HibernateCallback<List<User>>(){//start of AIC
public List<User> doInHibernate(Session session){	
Criteria criteria=session.createCriteria(User.class);	
	return criteria.list();
}//end of doInHibernate
});//end of AIC and execute()
		return list;
	}//end of getAllUsers()

public int deleteUser(final int userId) {
int count=hibernateTemplate.execute
(new HibernateCallback<Integer>(){//start of AIC
public Integer doInHibernate(Session session){
String hql="delete from com.nareshit.pojo.User as u where u.userId=:uid";
Query query=session.createQuery(hql);  
query.setParameter("uid",userId);
	return query.executeUpdate();
}
});		
	
return count;
}
public int createUser(final User user) {
int count=hibernateTemplate.execute
(new HibernateCallback<Integer>(){
public Integer doInHibernate(Session session){
String  sql="insert into user_details values (?,?,?,?)";
SQLQuery sqlQuery=session.createSQLQuery(sql);
sqlQuery.setParameter(0,user.getUserId());
sqlQuery.setParameter(1,user.getName());
sqlQuery.setParameter(2,user.getEmail());
sqlQuery.setParameter(3,user.getMobile());
return sqlQuery.executeUpdate();
	}	
});		
return count;
	}
}
