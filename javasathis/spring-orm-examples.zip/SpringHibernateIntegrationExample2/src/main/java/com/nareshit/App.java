package com.nareshit;

import java.util.List;

import javax.jws.soap.SOAPBinding.Use;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nareshit.dao.UserDAO;
import com.nareshit.pojo.User;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args){
   ApplicationContext context=new
		   ClassPathXmlApplicationContext("com/nareshit/cfg/myBeans.xml");
  UserDAO userDAO=context.getBean("userDao",UserDAO.class);
    /*List<User> list=userDAO.getAllUsers();
    for(User user:list){
    	System.out.println(user.getUserId()+" "+user.getName()+" "+user.getEmail()+" "+user.getMobile());
    }*/
  /*System.out.println(userDAO.deleteUser(102));
 */ 
  
User user=new User();
  user.setUserId(101);
  user.setName("rama");
  user.setEmail("rama@gmail.com");
  user.setMobile("9999999");
  int count=userDAO.createUser(user);
  System.out.println(count);
    }
}



