package com.nareshit.dao;

import java.util.List;

import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.nareshit.pojo.User;

public class UserDAOImpl 
implements UserDAO{
	private HibernateTemplate hibernateTemplate;
	
  public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
@Transactional(readOnly=false)
public Integer createUser(User user) {
Integer userId=(Integer)hibernateTemplate.save(user);
		return userId;
	}
public User getUser(int userId) {
User user=hibernateTemplate.get(User.class,userId);
	return user;
}
//@Transactional(readOnly=false)
public int deleteUser(int userId) {
String hql="delete from com.nareshit.pojo.User as u where u.userId=?";
int count=hibernateTemplate.bulkUpdate(hql,userId);
	return count;
}
public List<?> getAllUsers() {
String hql="from  com.nareshit.pojo.User ";
List<?> list=hibernateTemplate.find(hql);
	return list;
}
public List<?> getAllUsers(String name) {
	String hql="from  com.nareshit.pojo.User as u where u.name like :name";
	List<?> list=hibernateTemplate.findByNamedParam(hql,"name",name);
		return list;
}
}
