package com.nareshit.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nareshit.dao.UserDAO;
import com.nareshit.pojo.User;

public class App {
    public static void main( String[] args){
    ApplicationContext context=new 
    		ClassPathXmlApplicationContext("com/nareshit/cfg/myBeans.xml");
    UserDAO userDAO=context.getBean("userDAO",UserDAO.class);
    /*User user=new User();
    user.setUserId(105);
    user.setName("rama");
    user.setEmail("rama@gmail.com");
    user.setMobile("33999999");
    Integer userId=userDAO.createUser(user);
        System.out.println(userId);*/
  /* User user=userDAO.getUser(101);
   System.out.println(user.getName()+" "+user.getEmail()+" "+user.getMobile());*/
       List<?> list=userDAO.getAllUsers("rama");
       for(Object obj:list){
    	   User user=(User)obj;
    	  System.out.println(user.getName()+" "+user.getEmail()+" "+user.getMobile()+" "+user.getUserId()); 
       }
   // System.out.println(userDAO.deleteUser(101));
    }
}
