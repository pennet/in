package com.nareshit.dao;

import java.util.List;

import com.nareshit.pojo.User;

public interface UserDAO {
public Integer createUser(User user);
public User getUser(int userId);
public int deleteUser(int userId);
public List<?> getAllUsers();
public List<?> getAllUsers(String name);
}
