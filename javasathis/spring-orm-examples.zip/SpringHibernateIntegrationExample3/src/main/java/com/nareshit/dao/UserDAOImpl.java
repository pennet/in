package com.nareshit.dao;

import java.util.List;

import javax.jws.soap.SOAPBinding.Use;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nareshit.pojo.User;

@Repository("userDao")
public class UserDAOImpl implements
UserDAO{
     @Autowired
	private SessionFactory sessionFactory;

	public List<User> getAllUsers() {
	Session session=sessionFactory.openSession();
	Criteria criteria=session.createCriteria(User.class);
	  List<User> list=criteria.list();
	session.close();
		return list;
	}

	public int createUser(User user) {
	Session session=sessionFactory.openSession();
	Transaction transaction=session.beginTransaction();
		String sql="insert into User_Details values (?,?,?,?)";
   SQLQuery query=session.createSQLQuery(sql);
	query.setParameter(0,user.getUserId());
	query.setParameter(1,user.getName());
	query.setParameter(2,user.getEmail());
	query.setParameter(3,user.getMobile());
	int count=query.executeUpdate();
	transaction.commit();
		session.close();
		return count;
	}

	public int deleteUser(int userId) {
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
	String hql="delete from com.nareshit.pojo.User as u where u.userId=:uid";
			
	   Query query=session.createQuery(hql);
		query.setParameter("uid",userId);
		int count=query.executeUpdate();
		transaction.commit();
			session.close();
			return count;
	}

}
