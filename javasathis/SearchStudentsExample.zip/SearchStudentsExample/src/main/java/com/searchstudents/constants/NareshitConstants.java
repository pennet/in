package com.searchstudents.constants;

public class NareshitConstants {
public static final String CONST_STUDENT_ID="studentId";
public static final String CONST_STUDENT_NAME="name";
public static final String CONST_STUDENT_COURSE="course";
public static final String CONST_STUDENT_MOBILE="mobile";

}
