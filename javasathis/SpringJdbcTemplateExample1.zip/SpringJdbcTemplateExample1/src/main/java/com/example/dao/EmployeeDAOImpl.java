package com.example.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.example.domain.Employee;

import java.sql.PreparedStatement;

public class EmployeeDAOImpl implements EmployeeDAO {
private JdbcTemplate jdbcTemplate;

public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
}

public int createEmployee(Employee emp) {
String sql="insert into Employee_Details values(?,?,?,?,?)";
int count=jdbcTemplate.update(sql,new Object[]{emp.getEmpNo(),emp.getName(),emp.getSalary(),emp.getDeptName(),emp.getDeptNo()},new int[]{Types.INTEGER,Types.VARCHAR,Types.DOUBLE,Types.VARCHAR,Types.INTEGER});
return count;
}

public int updateEmployeeName(final int empNo,final String name) {
String sql="update employee_details set name=? where empNo=?";
int count=jdbcTemplate.update(sql,
		new PreparedStatementSetter(){
public void setValues(PreparedStatement pst)throws SQLException{	
	pst.setString(1, name);
	pst.setInt(2,empNo);
}
});
	return count;
}

public int deleteEmployee(final int empNo) {
int count=jdbcTemplate.update(
		new PreparedStatementCreator(){
public PreparedStatement 
createPreparedStatement(Connection con)throws SQLException{	
String sql="delete from employee_details where empNo=?";
PreparedStatement pst=con.prepareStatement(sql);
pst.setInt(1, empNo);
return pst;
}
});
return count;
}

public int getEmpDeptNo(int empNo) {
String sql=
"select deptNo from employee_details where empNo=?";
int deptNo=jdbcTemplate.queryForInt(sql,empNo);
	return deptNo;
}

public String getDeptName(int empNo) {
String sql="select deptName from employee_details where empNo=?";
String deptName=jdbcTemplate.queryForObject(sql,String.class,empNo);	
	return deptName;
}

public Map<String, Object> getEmployee(int empNo) {
	String sql="select * from employee_details where empNo=?";
Map<String,Object> map=
jdbcTemplate.queryForMap(sql,empNo);	
	return map;
}

public List<Map<String,Object>> getAllEmployees() {
	String sql="select *from employee_details";
List<Map<String,Object>> list=jdbcTemplate.queryForList(sql);
	return list;
}

}
