package com.example.dao;

import java.util.List;
import java.util.Map;

import com.example.domain.Employee;

public interface EmployeeDAO {
public int createEmployee(Employee emp);
public int updateEmployeeName(int empNo,String name);
public int deleteEmployee(int empNo);
public int getEmpDeptNo(int empNo);
public String getDeptName(int empNo);
public Map<String,Object> getEmployee(int empNo);
public List getAllEmployees();
}
