package com.example.client;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.dao.EmployeeDAO;
import com.example.domain.Employee;

public class App 
{
    public static void main( String[] args )
    {
 ApplicationContext context=new ClassPathXmlApplicationContext("com/example/cfg/myBeans.xml");
 EmployeeDAO employeeDAO=context.getBean("employeeDAO",EmployeeDAO.class);
 /*Employee emp=new Employee();
 emp.setEmpNo(102);
 emp.setName("raoja");
 emp.setSalary(9200.0);
 emp.setDeptNo(12);
 emp.setDeptName("sales");
 int count=employeeDAO.createEmployee(emp);
 System.out.println(count);*/
 /*System.out.println(employeeDAO.updateEmployeeName(101, "A Raja"));
 */
 /*System.out.println(employeeDAO.deleteEmployee(101));
 */
 //System.out.println("deptNo :"+employeeDAO.getEmpDeptNo(101));
   
 //System.out.println("deptName :"+employeeDAO.getDeptName(101));
    /*Map<String,Object> map=employeeDAO.getEmployee(101);
    Set<String> keys=map.keySet();
    for(String key:keys){
    Object value=map.get(key);
    System.out.println(key+"="+value);
    }*/
List<Map<String,Object>> list=employeeDAO.getAllEmployees();
for(Map<String,Object> map:list){
    Set<String> keys=map.keySet();
    for(String key:keys){
    Object value=map.get(key);
    System.out.println(key+"="+value);
    }
    System.out.println("-----------");
}
    }
}



