package com.jaxwsexamples.publisher;

import javax.xml.ws.Endpoint;

import com.jaxwsexamples.authentication.CompanyServiceImpl;

public class CompanyMain {
	public static final String endPointURI = "http://localhost:1414/JaxWSProviderApplicationAuthentication/getEmployees";

	public static void main(String[] args) {
		CompanyServiceImpl compImpl = new CompanyServiceImpl();
		
		Endpoint.publish(endPointURI, compImpl);
		System.out.println("webservice published successfully");

	}

}
