package com.jaxwsexamples.authentication;

public class AuthenticationException 
extends Exception{
	
	AuthenticationException(String message){
		super(message);
	}
}
