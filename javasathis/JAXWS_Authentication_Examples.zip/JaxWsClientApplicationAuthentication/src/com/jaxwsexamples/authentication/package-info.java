@javax.xml.bind.annotation.XmlSchema(namespace = "http://authentication.jaxwsexamples.com/")
package com.jaxwsexamples.authentication;
